package com.example.demo.services;

import com.example.demo.models.Response;

public interface IService {
    public Response getStatus(String url);
}
