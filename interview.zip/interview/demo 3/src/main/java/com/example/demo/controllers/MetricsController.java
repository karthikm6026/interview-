package com.example.demo.controllers;


import com.example.demo.models.Response;
import com.example.demo.services.NetworkService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@CrossOrigin
public class MetricsController {

    @Autowired
    NetworkService networkService;

    @GetMapping("/v1/amazon-status")
    public Response amazonStatus() {
        return networkService.getStatus("http://www.amazon.com");
    }

    @GetMapping("/v1/google-status")
    public Response googleStatus() {
        return networkService.getStatus("https://www.google.com/");
    }

    @GetMapping("/v1/all")
    public List<Response> allStatus() {
        List<Response> responses = new ArrayList<>();
        responses.add(networkService.getStatus("https://www.google.com/"));
        responses.add(networkService.getStatus("https://www.amazon.com/"));
        return responses;
    }
}
