package com.example.demo.services;

import com.example.demo.models.Response;
import org.springframework.stereotype.Service;

import java.net.HttpURLConnection;
import java.net.URL;

@Service
public class NetworkService implements IService {
    @Override
    public Response getStatus(String url) {
        Response response = new Response();
        try {
            long time = System.currentTimeMillis();
            URL request_url = new URL(url);
            HttpURLConnection con = (HttpURLConnection) request_url.openConnection();
            con.setRequestMethod("GET");
            con.connect();
            response.setUrl(String.valueOf(con.getURL()));
            response.setStatusCode(String.valueOf(con.getResponseCode()));
            response.setDuration(System.currentTimeMillis()-time);
            response.setDate(con.getDate());
            con.disconnect();
        } catch (Exception e) {
            response.setUrl(url);
            response.setStatusCode("500");
        }
        return response;
    }
}
