import React, { useState, useEffect } from "react";

const Metrics = () => {
  const [minutes, setMinutes] = useState(0);
  const [isActive, setIsActive] = useState(false);
  const [amazonData, setAmazonData] = useState({
    url: "",
    statusCode: "",
    duration: "",
    date: "",
  });
  const [googleData, setGoogleData] = useState({
    url: "",
    statusCode: "",
    duration: "",
    date: "",
  });
  function toggle() {
    setIsActive(!isActive);
  }

  function reset() {
    setMinutes(0);
    setIsActive(false);
  }

  useEffect(() => {
    let interval = null;
    async function fetchData() {
      const amazon_metric = await fetch(
        "http://localhost:8080/v1/amazon-status"
      );
      const amazon_metric_data = await amazon_metric.json();
      setAmazonData(amazon_metric_data);
      const google_metric = await fetch(
        "http://localhost:8080/v1/google-status"
      );
      const google_metric_data = await google_metric.json();
      setGoogleData(google_metric_data);
    }
    fetchData();
    if (isActive) {
      interval = setInterval(async () => {
        setMinutes((minutes) => minutes + 1);
        fetchData();
      }, 60000);
    } else if (!isActive && minutes !== 0) {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [isActive, minutes]);

  return (
    <div className="container">
      <div className="row mt-5">
        <div class="alert alert-success w-100" role="alert">
          <h4 class="alert-heading">Welcome to server stats!</h4>
          <span className="float-right">{minutes}</span>
          <p>The data will be auto refreshed for every minute...</p>
          <hr />
          <p class="mb-0">
            Please make use of start and reset button to see the server stats...
          </p>
        </div>
        <div className="bg-light col-4 p-3 m-3">
          <div>
            <span className="badge badge-warning">Server Name:</span>
            <span className="pl-3">Google</span>
          </div>
          <div>
            <span className="badge badge-primary">url:</span>
            <span className="pl-3">{googleData.url}</span>
          </div>
          <div>
            <span className="badge badge-danger">statusCode:</span>
            <span className="pl-3">{googleData.statusCode}</span>
          </div>
          <div>
            <span className="badge badge-success">duration:</span>
            <span className="pl-3">{googleData.duration}</span>
          </div>
          <div>
            <span className="badge badge-info">date:</span>
            <span className="pl-3">{googleData.date}</span>
          </div>
        </div>

        <div className="bg-light col-4 p-3 m-3">
          <div>
            <span className="badge badge-warning">Server Name:</span>
            <span className="pl-3">Amazon</span>
          </div>
          <div>
            <span className="badge badge-primary">url:</span>
            <span className="pl-3">{amazonData.url}</span>
          </div>
          <div>
            <span className="badge badge-danger">statusCode:</span>
            <span className="pl-3">{amazonData.statusCode}</span>
          </div>
          <div>
            <span className="badge badge-success">duration:</span>
            <span className="pl-3">{amazonData.duration}</span>
          </div>
          <div>
            <span className="badge badge-info">date:</span>
            <span className="pl-3">{amazonData.date}</span>
          </div>
        </div>
      </div>
      <div className="row m-3 float-right">
        <button
          className={`btn btn-primary btn-primary-${
            isActive ? "active" : "inactive"
          }`}
          onClick={toggle}
        >
          {isActive ? "Pause" : "Start"}
        </button>
        <button className="ml-2 btn btn-secondary" onClick={reset}>
          Reset
        </button>
      </div>
    </div>
  );
};

export default Metrics;
