import "./App.css";
import Metrics from "./Metrics";

function App() {
  return (
    <div>
      <Metrics />
    </div>
  );
}

export default App;
